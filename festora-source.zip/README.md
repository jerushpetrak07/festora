# FESTORA

A responsive festival-discovery website starter built with React and Vite.

**Important:** The public Emergent preview URL only exposed a JavaScript-required shell during inspection, so the original private source and all interactions could not be extracted from the link. This repository is a new recreation inspired by a festival-discovery concept, not the original Emergent source. Compare it with your live site and send screenshots if you want a closer match.

## Included features
- Responsive landing page
- Festival cards with sample content
- Search by festival, region, category, or tags
- Category filtering
- Save/unsave favourites in the current session
- Festival details modal
- Mobile navigation
- Empty-results state

## Run locally
Install Node.js 18+ and npm, then run:

```bash
npm install
npm run dev
```

Open the local URL Vite prints (usually http://localhost:5173).

Build and preview:

```bash
npm run build
npm run preview
```

## Upload to GitHub for free
1. Extract `festora-source.zip` on your computer.
2. Go to GitHub and create a new repository named `festora`.
3. Upload the contents of the extracted `festora` folder (the files and `src` folder, not the ZIP file).
4. Commit the files to the `main` branch.

For deployment, connect the repository to a static hosting service and use:
- Build command: `npm run build`
- Output directory: `dist`

## Structure

```text
festora/
├── index.html
├── package.json
├── README.md
├── .gitignore
└── src/
    ├── App.jsx
    ├── main.jsx
    └── styles.css
```

## Customisation
- `src/App.jsx`: festival content, search, filters, saved items, and modal
- `src/styles.css`: design, layout, responsive styles
- `index.html`: browser title and metadata

## Limitations
This is frontend-only. Login, a database, payments, admin dashboards, or external APIs are not included because they could not be verified from the preview. Saved items reset on page refresh. Festival text and image URLs are sample content and should be checked before presenting the site as production-ready.
