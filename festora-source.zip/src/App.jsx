import React, { useMemo, useState } from 'react';
import { ArrowUpRight, CalendarDays, Heart, MapPin, Menu, Search, Sparkles, X, Globe2 } from 'lucide-react';

const festivals = [
  { id: 1, name: 'Diwali', region: 'Across India', season: 'October – November', category: 'Light & tradition', image: 'https://images.unsplash.com/photo-1605379399642-870262d3d051?auto=format&fit=crop&w=1200&q=85', accent: 'orange', description: 'A festival of lights celebrating hope, new beginnings, and the triumph of light over darkness.', tags: ['Lights', 'Family', 'Tradition'] },
  { id: 2, name: 'Onam', region: 'Kerala', season: 'August – September', category: 'Harvest celebration', image: 'https://images.unsplash.com/photo-1593693397690-362cb9666fc2?auto=format&fit=crop&w=1200&q=85', accent: 'green', description: 'Kerala comes alive with floral carpets, boat races, traditional feasts, music, and the story of King Mahabali.', tags: ['Harvest', 'Food', 'Dance'] },
  { id: 3, name: 'Holi', region: 'Across India', season: 'March', category: 'Colour & joy', image: 'https://images.unsplash.com/photo-1598514982205-f36b96d1e8d7?auto=format&fit=crop&w=1200&q=85', accent: 'pink', description: 'Welcome spring with playful colours, music, community, and the joy of new beginnings.', tags: ['Colours', 'Music', 'Community'] },
  { id: 4, name: 'Pongal', region: 'Tamil Nadu', season: 'January', category: 'Harvest celebration', image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=85', accent: 'gold', description: 'A thanksgiving to the Sun, nature, and cattle, celebrated with sweet pongal and beautiful kolam designs.', tags: ['Harvest', 'Nature', 'Food'] },
  { id: 5, name: 'Durga Puja', region: 'West Bengal', season: 'September – October', category: 'Art & devotion', image: 'https://images.unsplash.com/photo-1606293926075-69a00dbind?auto=format&fit=crop&w=1200&q=85', accent: 'red', description: 'A spectacular celebration of devotion, craftsmanship, community pandals, and the triumph of good.', tags: ['Art', 'Music', 'Community'] },
  { id: 6, name: 'Bihu', region: 'Assam', season: 'April', category: 'Harvest celebration', image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=85', accent: 'blue', description: 'Celebrate Assamese culture through folk dances, music, seasonal food, and community gatherings.', tags: ['Dance', 'Music', 'Harvest'] }
];

const categories = ['All festivals', 'Harvest celebration', 'Light & tradition', 'Colour & joy', 'Art & devotion'];

export default function App() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All festivals');
  const [saved, setSaved] = useState([]);
  const [savedOnly, setSavedOnly] = useState(false);
  const [active, setActive] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);

  const shown = useMemo(() => festivals.filter(f => {
    const text = `${f.name} ${f.region} ${f.category} ${f.tags.join(' ')}`.toLowerCase();
    return text.includes(search.toLowerCase()) &&
      (category === 'All festivals' || f.category === category) &&
      (!savedOnly || saved.includes(f.id));
  }), [search, category, savedOnly, saved]);

  function toggleSaved(id) {
    setSaved(old => old.includes(id) ? old.filter(x => x !== id) : [...old, id]);
  }
  function explore() {
    document.getElementById('explore')?.scrollIntoView({ behavior: 'smooth' });
  }

  return <div className="app">
    <header className="navbar">
      <a className="logo" href="#home"><span className="logo-icon">F</span> FESTORA<span className="period">.</span></a>
      <nav className={menuOpen ? 'nav-links show' : 'nav-links'}>
        <a href="#explore" onClick={() => setMenuOpen(false)}>Explore</a>
        <a href="#story" onClick={() => setMenuOpen(false)}>Our story</a>
        <button className="nav-saved" onClick={() => { setSavedOnly(v => !v); explore(); setMenuOpen(false); }}><Heart size={15} fill={savedOnly ? 'currentColor' : 'none'}/> Saved <span>{saved.length}</span></button>
      </nav>
      <button className="nav-cta" onClick={explore}>Find your festival <ArrowUpRight size={16}/></button>
      <button className="menu-button" aria-label="Toggle menu" onClick={() => setMenuOpen(v => !v)}>{menuOpen ? <X/> : <Menu/>}</button>
    </header>

    <main id="home">
      <section className="hero">
        <div className="hero-bg"></div>
        <div className="hero-content">
          <div className="eyebrow"><Sparkles size={14}/> A WORLD OF TRADITIONS, ONE PLACE</div>
          <h1>Every festival<br/>has a <em>story.</em></h1>
          <p>Find the colours, flavours, rituals, and people that make every celebration unforgettable.</p>
          <div className="hero-buttons"><button className="primary" onClick={explore}>Explore festivals <ArrowUpRight size={17}/></button><a href="#story">Discover FESTORA <span>↗</span></a></div>
          <div className="hero-note"><span>✳</span> Rooted in culture. Made for everyone.</div>
        </div>
        <div className="hero-stamp"><Globe2 size={18}/><span>Culture connects<br/>us all</span></div>
        <div className="hero-side">01 / 06 <i/> CELEBRATE DIFFERENTLY</div>
      </section>

      <section className="story-strip" id="story">
        <div className="small-label">THE FESTORA EXPERIENCE</div>
        <p>More than dates on a calendar. <strong>A doorway into the stories that bring us together.</strong></p>
        <span className="ornament">✳</span>
      </section>

      <section className="explore" id="explore">
        <div className="section-heading">
          <div><div className="eyebrow dark"><span className="dash"/> YOUR NEXT CULTURAL DISCOVERY</div><h2>Celebrate <em>something</em><br/>meaningful.</h2></div>
          <p>From age-old rituals to vibrant street celebrations, find a festival that speaks to you.</p>
        </div>
        <div className="tools">
          <label className="search"><Search size={18}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search a festival, place, or tradition..." aria-label="Search festivals"/>{search && <button onClick={() => setSearch('')} aria-label="Clear search">×</button>}</label>
          <button className={savedOnly ? 'saved-filter active' : 'saved-filter'} onClick={() => setSavedOnly(v => !v)}><Heart size={16} fill={savedOnly ? 'currentColor' : 'none'}/> Saved ({saved.length})</button>
        </div>
        <div className="categories">{categories.map(c => <button key={c} onClick={() => setCategory(c)} className={category === c ? 'chip active' : 'chip'}>{c}</button>)}</div>
        <div className="result-line"><span>{shown.length} FESTIVALS TO DISCOVER</span><span>CURATED FOR THE CURIOUS</span></div>
        {shown.length ? <div className="festival-grid">{shown.map(f => <article className="festival-card" key={f.id}>
          <div className="photo" role="button" tabIndex="0" onClick={() => setActive(f)} onKeyDown={e => e.key === 'Enter' && setActive(f)} aria-label={`Explore ${f.name}`}>
            <img src={f.image} alt={`${f.name} celebration`} loading="lazy" onError={e => { e.currentTarget.style.display = 'none'; }}/>
            <span className="photo-number">0{f.id}</span><span className="photo-arrow"><ArrowUpRight size={18}/></span>
          </div>
          <button className={saved.includes(f.id) ? 'heart saved' : 'heart'} onClick={() => toggleSaved(f.id)} aria-label={saved.includes(f.id) ? 'Remove saved festival' : 'Save festival'}><Heart size={17} fill={saved.includes(f.id) ? 'currentColor' : 'none'}/></button>
          <div className="card-body">
            <div className="card-kicker"><i className={f.accent}/> {f.category}</div>
            <div className="title-line"><h3>{f.name}</h3><span><MapPin size={12}/>{f.region}</span></div>
            <p>{f.description}</p>
            <div className="card-foot"><span><CalendarDays size={14}/>{f.season}</span><button onClick={() => setActive(f)}>Discover <ArrowUpRight size={14}/></button></div>
          </div>
        </article>)}</div> : <div className="empty"><span>✳</span><h3>No festivals found just yet.</h3><p>Try a different search or clear your filters.</p><button className="primary" onClick={() => { setSearch(''); setCategory('All festivals'); setSavedOnly(false); }}>Show all festivals</button></div>}
        <div className="end-note"><i/> THE WORLD IS FULL OF REASONS TO CELEBRATE. <i/></div>
      </section>

      <section className="closing">
        <span className="closing-mark">✳</span><div><div className="eyebrow"><span className="dash"/> KEEP YOUR CURIOSITY ALIVE</div><h2>Come for the celebration.<br/><em>Stay for the story.</em></h2></div><button onClick={explore}>Find your next festival <ArrowUpRight size={17}/></button>
      </section>
    </main>
    <footer><a className="logo" href="#home"><span className="logo-icon">F</span> FESTORA<span className="period">.</span></a><p>Celebrating the stories that connect us.</p><span className="copyright">© {new Date().getFullYear()} FESTORA. MADE WITH CURIOSITY.</span></footer>

    {active && <div className="overlay" onClick={() => setActive(null)} role="presentation"><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" onClick={e => e.stopPropagation()}>
      <button className="close" onClick={() => setActive(null)} aria-label="Close"><X/></button><img src={active.image} alt="" onError={e => e.currentTarget.style.display = 'none'}/>
      <div className="modal-content"><div className="eyebrow dark"><MapPin size={14}/>{active.region}</div><h2 id="modal-title">{active.name}</h2><p>{active.description}</p><div className="modal-date"><CalendarDays size={16}/>{active.season}</div><div className="tags">{active.tags.map(t => <span key={t}>{t}</span>)}</div><button className="primary" onClick={() => toggleSaved(active.id)}><Heart size={16} fill={saved.includes(active.id) ? 'currentColor' : 'none'}/>{saved.includes(active.id) ? 'Saved to your list' : 'Save this festival'}</button></div>
    </section></div>}
  </div>;
}